﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BackGroundJobs.Models
{

        public class EmailSend
        {
            public string name { get; set; }          
            public string mobile { get; set; }
            public string email { get; set; }
            public string subject { get; set; }
            public string toAddress { get; set; }
            public string emailbody { get; set; }
        }

    public class Customer
    {
        public int Id { get; set; }
        public string customerId { get; set; }
        public string name { get; set; }
        public string mobile { get; set; }
        public string emailId { get; set; } 
        public string projectCode { get; set; }
        public string leadSourceCode { get; set; }
        public string leadStatus { get; set; }
        public DateTime leadCreationDate { get; set; }
        public DateTime followupDate { get; set; }
        public string lastUpdateToken { get; set; }
        public string lastModifiedBy { get; set; }
        public string assignedTo { get; set; }
        public string shareHistory { get; set; }
        public string shareComments { get; set; }

    }

}
