using NetCoreAudio;

namespace BackGroundJobs
{
    public class Worker : BackgroundService
    {
        private readonly ILogger<Worker> _logger;
        private IConfiguration configuration;
        public Worker(ILogger<Worker> logger,IConfiguration iConfig)
        {
            _logger = logger;
            configuration = iConfig;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            while (!stoppingToken.IsCancellationRequested)
            {   
                _logger.LogInformation("Worker running at: {time}", DateTimeOffset.Now);
               
                WaslListenerJob.SearchAvailableInventory(configuration);
                await Task.Delay(300000, stoppingToken);
            }
        }




    }
}